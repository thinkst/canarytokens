--
-- Table structure for table `dw_users`
--

DROP TABLE IF EXISTS `dw_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dw_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime ,
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dw_users`
--

LOCK TABLES `dw_users` WRITE;
/*!40000 ALTER TABLE `dw_users` DISABLE KEYS */;
INSERT INTO `dw_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES (1,'admin','$P$B.4prv4AhSkyGWnWi33xRuA.vlGAjo/','admin','dgurney@dwq.com','','2012-11-10 04:46:18','$P$B5FXaPuc5Wwod9l52O1qweu7xl9s1B1',0,'admin'),(3,'edelacruz','$P$BU0kf2Hp815qPamQRUPz.U94Th6C690','edelacruz','edelacruz@dwq.com','','2013-01-26 00:20:21','',0,'edelacruz'),(4,'lweisgarber','$P$BUzJ64vewpwqYVEuir2IsPoX9olQ1m1','lweisgarber','lweisgarber@dwq','','2013-01-26 00:21:26','',0,'lweisgarber'),(5,'mlovering','$P$BM1v8n7XYUxQNdqcLUAi7lD1ZyIwNm0','mlovering','mlovering@dwq.com','','2013-01-26 00:22:10','',0,'mlovering'),(6,'ldmyterko','$P$BceXCTI1itIXoX0nezKYaZ.E5OKF5Z1','ldmyterko','ldmyterko@dwq.com','','2013-01-26 00:23:20','',0,'ldmyterko'),(7,'smahar','$P$Byx3NrOX/c6QExd8Lxa/8Se5zYbJno0','smahar','smahar@dwq.com','','2013-01-26 00:23:52','',0,'smahar'),(9,'aguzman','$P$BcMCWey/se9halr7OmkgNfGyxzj.2x.','aguzman','aguzman@dwq.com','','2013-01-26 00:27:08','',0,'aguzman'),(11,'jbattle','$P$Bjk/tGc0D.5OtxzksVknjqyuN769L51','jbattle','jbattle@dwq.com','','2014-06-02 16:50:43','',0,'Jeff Battle'),(12,'ebattle','$P$B1qMYcIH9wUMzdE/2H2rdTFWkUN.Fj/','ebattle','ebattle@dwq.com','','2014-06-02 16:51:21','',0,'Erica Battle'),(13,'JGurney','$P$BJLbnJWWCkmbvPjWGfKqbRqTDHTxpV0','jgurney','gurney_rxn@dwq.com','','2014-10-28 18:43:12','',0,'Joan Gurney'),(14,'aholmes','$P$Bku9rA5BnVFGrUEQ3sDBh1XPbpiw8S.','aholmes','adampeterholmes@dwq.com','','2015-11-02 18:10:58','',0,'Angel Guzman');
/*!40000 ALTER TABLE `dw_users` ENABLE KEYS */;
UNLOCK TABLES;